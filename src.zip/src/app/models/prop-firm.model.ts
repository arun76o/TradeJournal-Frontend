export interface PropFirm {
  id?: string;
  userId?: string;
  firmName: string;
  accountName?: string;
  accountId?: string;
  accountType?: string;
  initialBalance: number;
  accountCurrency: string;
  accountSize?: number | null;
  profitTarget?: number | null;
  maximumDailyLoss?: number | null;
  maximumOverallDrawdown?: number | null;
  startDate?: string | null;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}
