import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  NavigationEnd,
  Router,
  RouterOutlet,
} from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Subscription, filter } from 'rxjs';
import { PropFirmService } from '../services/prop-firm.service';
import { PropFirm } from '../models/prop-firm.model';

@Component({
  selector: 'app-prop-firms',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
  ],
  templateUrl: './prop-firms.component.html',
  styleUrls: ['./prop-firms.component.scss'],
})
export class PropFirmsComponent implements OnInit, OnDestroy {
  private propFirmService = inject(PropFirmService);
  private router = inject(Router);

  firms: PropFirm[] = [];
  selectedFirmId = '';
  isLoading = true;
  hasLoadedOnce = false;

  private previousId: string | null = null;
  private navSubscription?: Subscription;

  ngOnInit(): void {
    this.selectedFirmId = this.parseFirmId();
    this.loadFirms();

    this.navSubscription = this.router.events
      .pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe(() => this.syncSelection());
  }

  ngOnDestroy(): void {
    this.navSubscription?.unsubscribe();
  }

  loadFirms(): void {
    this.propFirmService.getPropFirms().subscribe({
      next: (firms) => {
        this.firms = firms;
        this.isLoading = false;
        this.hasLoadedOnce = true;
      },
      error: () => {
        this.firms = [];
        this.isLoading = false;
        this.hasLoadedOnce = true;
      },
    });
  }

  /**
   * Keeps the active state in sync with the URL and refreshes the list when the selection
   * changes to a firm that is not known yet (after creating one) or returns to the root
   * (after deleting one).
   */
  private syncSelection(): void {
    const id = this.parseFirmId();
    this.selectedFirmId = id;

    if (!this.hasLoadedOnce || this.previousId === null) {
      this.previousId = id;
      return;
    }

    const changed = this.previousId !== id;
    this.previousId = id;
    if (!changed) return;

    const needsReload = id === '' || !this.firms.some((f) => f.id === id);
    if (needsReload) this.loadFirms();
  }

  private parseFirmId(): string {
    const path = this.router.url.split('?')[0].split('/').filter(Boolean);
    const index = path.indexOf('prop-firms');
    const rest = index >= 0 ? path.slice(index + 1) : [];

    if (rest.length === 0) return '';
    if (rest[0] === 'add' || rest[0] === 'edit') return '';

    return rest[0];
  }

  selectFirm(firm: PropFirm): void {
    if (!firm.id) return;
    this.router.navigate(['/prop-firms', firm.id]);
  }

  addFirm(): void {
    this.router.navigate(['/prop-firms/add']);
  }
}
