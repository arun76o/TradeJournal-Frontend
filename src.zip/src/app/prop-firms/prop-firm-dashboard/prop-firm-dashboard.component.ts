import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration } from 'chart.js';
import { Subscription } from 'rxjs';
import { PropFirmService } from '../../services/prop-firm.service';
import { PropFirmTradeService } from '../../services/prop-firm-trade.service';
import { PropFirm } from '../../models/prop-firm.model';
import { PropFirmTrade } from '../../models/prop-firm-trade.model';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { KpiCardComponent } from '../../shared/components/kpi-card/kpi-card.component';
import { AlertService } from '../../core/services/alert.service';
import { getBaseChartOptions } from '../../core/utils/chart-options.util';
import { DashboardStats } from '../../core/utils/trade-analytics.util';
import {
  computeDrawdownFromInitial,
  computeFirmDrawdown,
  computeFirmEquity,
  computePropFirmStats,
  computeTodayPnL,
  formatFirmCurrency,
  getPropTradeStatus,
} from '../../core/utils/prop-firm-analytics.util';

@Component({
  selector: 'app-prop-firm-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    BaseChartDirective,
    PageHeaderComponent,
    KpiCardComponent,
  ],
  templateUrl: './prop-firm-dashboard.component.html',
  styleUrls: ['./prop-firm-dashboard.component.scss'],
})
export class PropFirmDashboardComponent implements OnInit, OnDestroy {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private propFirmService = inject(PropFirmService);
  private propFirmTradeService = inject(PropFirmTradeService);
  private alertService = inject(AlertService);

  firmId = '';
  firm: PropFirm | null = null;
  trades: PropFirmTrade[] = [];
  recentTrades: PropFirmTrade[] = [];
  stats: DashboardStats | null = null;

  isLoading = true;
  loadError = '';

  currentBalance = 0;
  todayPnl = 0;
  drawdownFromInitial = 0;
  peakDrawdown = 0;

  equityChartData: ChartConfiguration<'line'>['data'] = {
    labels: [],
    datasets: [
      {
        label: 'Equity',
        data: [],
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
      },
    ],
  };
  equityOptions = getBaseChartOptions();

  private paramSubscription?: Subscription;

  ngOnInit(): void {
    this.paramSubscription = this.route.paramMap.subscribe((params) => {
      this.firmId = params.get('id') ?? '';
      this.reload();
    });
  }

  ngOnDestroy(): void {
    this.paramSubscription?.unsubscribe();
  }

  private reload(): void {
    this.isLoading = true;
    this.loadError = '';
    this.firm = null;
    this.trades = [];
    this.recentTrades = [];
    this.stats = null;

    if (!this.firmId) {
      this.isLoading = false;
      return;
    }

    this.propFirmService.getPropFirm(this.firmId).subscribe({
      next: (firm) => {
        this.firm = firm;
        this.loadTrades();
      },
      error: (err) => {
        this.isLoading = false;
        this.loadError =
          err?.status === 403
            ? 'You do not have permission to access this prop firm.'
            : 'This prop firm could not be found.';
      },
    });
  }

  private loadTrades(): void {
    this.propFirmTradeService.getTrades(this.firmId).subscribe({
      next: (trades) => {
        this.trades = trades;
        this.buildView();
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      },
    });
  }

  private buildView(): void {
    const initial = Number(this.firm?.initialBalance ?? 0);

    this.stats = computePropFirmStats(this.trades);
    this.currentBalance = initial + (this.stats?.totalPnL ?? 0);
    this.todayPnl = computeTodayPnL(this.trades);
    this.drawdownFromInitial = computeDrawdownFromInitial(this.trades, initial);
    this.peakDrawdown = computeFirmDrawdown(this.trades).maxDrawdown;

    this.recentTrades = this.trades.slice(0, 8);

    const equity = computeFirmEquity(this.trades, initial);
    this.equityChartData = {
      labels: equity.labels,
      datasets: [
        {
          label: `${this.currency} Equity`,
          data: equity.data,
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.08)',
          fill: true,
          tension: 0.4,
          pointRadius: equity.data.length > 30 ? 0 : 3,
        },
      ],
    };
  }

  get currency(): string {
    return (this.firm?.accountCurrency || '').toUpperCase() || 'INR';
  }

  get hasTrades(): boolean {
    return this.trades.length > 0;
  }

  get netPnl(): number {
    return this.stats?.totalPnL ?? 0;
  }

  get winRateDisplay(): string {
    return `${this.stats?.winRate ?? 0}%`;
  }

  get profitTargetProgress(): number | null {
    const target = Number(this.firm?.profitTarget ?? 0);
    if (!target || target <= 0) return null;
    const achieved = this.currentBalance - Number(this.firm?.initialBalance ?? 0);
    return (achieved / target) * 100;
  }

  get dailyLossUsage(): number | null {
    const limit = Number(this.firm?.maximumDailyLoss ?? 0);
    if (!limit || limit <= 0) return null;
    const used = Math.max(0, -this.todayPnl);
    return (used / limit) * 100;
  }

  get overallDrawdownUsage(): number | null {
    const limit = Number(this.firm?.maximumOverallDrawdown ?? 0);
    if (!limit || limit <= 0) return null;
    return (this.drawdownFromInitial / limit) * 100;
  }

  formatMoney(value: number): string {
    return formatFirmCurrency(value, this.currency);
  }

  getStatus(trade: PropFirmTrade): string {
    return getPropTradeStatus(trade);
  }

  addPropFirm(): void {
    this.router.navigate(['/prop-firms/add']);
  }

  viewAllFirms(): void {
    this.router.navigate(['/prop-firms']);
  }

  addTrade(): void {
    this.router.navigate(['/prop-firms', this.firmId, 'add-trade']);
  }

  viewTrades(): void {
    this.router.navigate(['/prop-firms', this.firmId, 'trades']);
  }

  editFirm(): void {
    this.router.navigate(['/prop-firms/edit', this.firmId]);
  }

  deleteFirm(): void {
    const firm = this.firm;
    if (!firm?.id) return;

    const id = firm.id;
    const tradeCount = this.trades.length;
    const warning =
      tradeCount > 0
        ? `This prop firm has ${tradeCount} trade(s). Deleting it will also permanently ` +
          `delete all ${tradeCount} trade(s). This cannot be undone.`
        : 'This prop firm has no trades. This action cannot be undone.';

    this.alertService.confirm('Delete this prop firm?', warning).then((result) => {
      if (!result.isConfirmed) return;

      this.propFirmService.deletePropFirm(id).subscribe({
        next: () => {
          this.alertService.success(
            'Prop Firm Deleted',
            tradeCount > 0
              ? `Prop firm and its ${tradeCount} trade(s) were deleted.`
              : 'Prop firm deleted successfully.'
          );
          this.router.navigate(['/prop-firms']);
        },
        error: (err) => {
          if (err?.status === 409) {
            this.confirmDeleteWithTrades(id, err?.error?.tradeCount ?? tradeCount);
            return;
          }
          this.alertService.error('Delete Failed', 'Unable to delete the prop firm.');
        },
      });
    });
  }

  private confirmDeleteWithTrades(id: string, tradeCount: number): void {
    this.alertService
      .confirm(
        'Delete prop firm and all its trades?',
        `This prop firm still has ${tradeCount} trade(s). Deleting it will also ` +
          `permanently delete every one of those trades. This cannot be undone.`
      )
      .then((result) => {
        if (!result.isConfirmed) return;

        this.propFirmService.deletePropFirm(id, true).subscribe({
          next: () => {
            this.alertService.success(
              'Prop Firm Deleted',
              `Prop firm and its ${tradeCount} trade(s) were deleted.`
            );
            this.router.navigate(['/prop-firms']);
          },
          error: () => {
            this.alertService.error('Delete Failed', 'Unable to delete the prop firm.');
          },
        });
      });
  }
}
